# To import datasets from the working directory "readr" package is required.
install.packages("readr")
library("readr")
# At first, three datasets in the working directory are imported.
# The variable required for the analysis are saved in three different datasets imported.
# required colums from each dataset are extracted and merged into single data frame using cbind command.

Data <- Edu_Net_Data
Income <- Income_Data[,4]
Population <- Population_Data[,4]
Data <- as.data.frame(cbind(Data,Income,Population))
Data
str(Data)
attach(Data)

# Education: Percentage of population with age>=25 who achieved Diploma (at least)
# NoInternet: Percentage of households with no Internet access
# Income: Median of the household annual Income ($)
# Population: State Population

# "ggplot2" package is required for visulization.
install.packages("ggplot2")
library("ggplot2")

# Boxplot of Education
ggplot(Data, aes( x = "", y = Education)) +
  geom_boxplot(width = 0.5, fill = "lightblue", color = "blue", outlier.colour = "red", outlier.shape = 16, outlier.size = 3) +
  geom_dotplot(binaxis = "y", stackdir = "center", dotsize = 0.5, fill = "yellow") +
  theme_minimal() +
  labs(title = "Boxplot of Education", x = "", y = "Education Attainment (%)")
 
# Boxplot of NoInternet (%)
ggplot(Data, aes( x = "", y = NoInternet)) +
  geom_boxplot(width = 0.5, fill = "lightblue", color = "blue", outlier.colour = "red", outlier.shape = 16, outlier.size = 3) +
  geom_dotplot(binaxis = "y", stackdir = "center", dotsize = 0.5, fill = "yellow") +
  theme_minimal() +
  labs(title = "Boxplot of NoInternet (%)", x = "", y = "No Internet Access (%)")
  
# Boxplot of Income  
 ggplot(Data, aes( x = "", y = Income)) +
  geom_boxplot(width = 0.5, fill = "lightblue", color = "blue", outlier.colour = "red", outlier.shape = 16, outlier.size = 3) +
  geom_dotplot(binaxis = "y", stackdir = "center", dotsize = 0.5, fill = "yellow") +
  theme_minimal() +
  labs(title = "Boxplot of Income", x = "", y = "Median of the household Annual Income ($)")
  
# Boxplot of Population
  ggplot(Data, aes( x = "", y = Population)) +
   geom_boxplot(width = 0.5, fill = "lightblue", color = "blue", outlier.colour = "red", outlier.shape = 16, outlier.size = 3) +
   geom_dotplot(binaxis = "y", stackdir = "center", dotsize = 0.5, fill = "yellow") +
   theme_minimal() +
   labs(title = "Boxplot of Population", x = "", y = "State Population") 
# For any sort of analysis, we require to consider the population of the state corresponding
# to each line of the data; obviously 10% in Alaska is different to 10% in California.
# The population of each state is therefore used as the weight for each row of data.

# Independent Variable (IV): NoInternet, Dependent Variable (DV); Education
R1 <- lm(Data$Education ~ Data$NoInternet , weights = Data$Population)
summary(R1)

# The scatter plot for the above model
ggplot(Data, aes(x = NoInternet, y = Education, size = Population)) +
  geom_point() +    
  geom_smooth(method = "lm", se = FALSE, color = "red") + 
  labs(title = "% No Internet/Education Weighted Scatter Plot",
       x = "No Internet Access (%)", y = "Education Attainment (%)")

# Independent Variable (IV): NoInterne, Dependent Variable (DV); Income
R2 <- lm(Data$Income ~ Data$NoInternet  , data=Data, weights = Data$Population)
summary(R2)

# The scatter plot for the above model
ggplot(Data, aes(x = NoInternet, y = Income, size= Population)) +
  geom_point() +    
  geom_smooth(method = "lm", se = FALSE, color = "red") + 
  labs(title = "NoInternet/Income Weighted Scatter Plot",
       x = "No Internet Access (%)", y = "Median of the Annual Household Income ($)")

# Independent Variable (IV): Income, Dependent Variable (DV); Education
R3 <- lm(Data$Education ~ Data$Income , data=Data, weights = Data$Population)
summary(R3)

# The scatter plot for the above model
ggplot(Data, aes(x =Income, y = Education, size = Population)) +
  geom_point() +    
  geom_smooth(method = "lm", se = FALSE, color = "red") + 
  labs(title = "Income/Educatin Weighted Scatter Plot",
       x = "Median of the Annual Household Income ($)", y = "Education Attainment (%)")

# Independent Variable (IV): Income and NoInternet, Dependent Variable (DV); Education
R4 <- lm(Data$Education ~ Data$NoInternet+Data$Income, data=Data, weights = Data$Population)
summary(R4)

# The result shows that, Income is the partial mediator of the relationship between NoInternet and Education 

# Package required for 3D scaterplot
install.packages("scatterplot3d")
library(scatterplot3d)

# Create a 3D scatter plot
s3d <- scatterplot3d(Data$NoInternet, Data$Income, Data$Education, color="blue", pch=16, xlab = "No Internet Access (%)", ylab = "Median of the Annual Household Income ($)", zlab = "Education Attainment (%)")

# Add the regression plane to the 3D plot
s3d$plane3d(R4, col = "red", alpha = 0.5)


